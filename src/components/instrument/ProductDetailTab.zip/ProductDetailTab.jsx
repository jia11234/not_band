import React, { useState } from 'react'
import { Link, useNavigate, useLocation } from "react-router-dom";
import '../../css/main/index.css';
import '../../css/instrument/ProductDetail.css';
import '../../css/instrument/instrument.css';
export default function ProductDetailTab({ product, reviewCount, hasValidReviews, reviews, formatNumber, getAverageRating, 
    renderAverageStars, currentReviews, maskName, renderStars, itemsPerPage, handlePrev, totalPages, currentPage, handleNext }) {
    const [tab, setTab] = useState(1);

    const handlerTab = (value) => {
        setTab(value);  // 선택된 탭을 설정
    }

    return (
        <div className='tab_content'>
            <div className='detail_tab'>
                <div>
                    <div onClick={() => handlerTab(1)} className={tab === 1 ? 'active' : ''}>상세설명</div>
                    <div onClick={() => handlerTab(2)} className={tab === 2 ? 'active' : ''}>교환및반품</div>
                    <div onClick={() => handlerTab(3)} className={tab === 3 ? 'active' : ''}>리뷰</div>
                </div>
            </div>
                {tab === 1 && (
                    <img src={`/images/detail/${product.prdNo}.png`} alt={`${product.prdNo}`} className='con5' />
                )}
                {tab === 2 && (
                    <img src="/images/detail/return.png" alt="" />
                )}
                {tab === 3 && (
                     <div className='con3_group'>
                     {/* con3_title은 항상 보여줌 */}
                     <div className='con3_title'>
                         <p>상품리뷰</p>
                         <p>{formatNumber(reviewCount)}개</p>
                     </div>
 
                     {hasValidReviews ? (
                         <>
                             <div className='con3_aver_stars'>
                                 <p>평균 평점</p>
                                 <p>{getAverageRating(reviews)}</p>
                                 <div className='stars'>{renderAverageStars(getAverageRating(reviews))}</div>
                             </div>
 
                             <div className='con3_review_group'>
                                 {currentReviews.length === 0 ? (
                                     <p className='no_review_message'>작성된 리뷰가 없습니다</p>
                                 ) : (
                                     currentReviews.map((review, index) => (
                                         <div className='con3_user_review' key={index}>
                                             <div className='user_review_name'>
                                                 {maskName(review.username)}
                                                 {review.isBest && <div className='user_review_best'>BEST</div>}
                                             </div>
                                             <div className='user_review_text'>
                                                 <div>{renderStars(review.rating)}</div>
                                                 <p>{review.content}</p>
                                                 {review.image && review.image.trim() !== '' && (
                                                     <img className='review_text_img' src={review.image} alt={`${review.username}의 후기 이미지`} />
                                                 )}
                                                 <p className='user_review_date'>{new Date().toISOString().slice(0, 10).replace(/-/g, '.')}</p>
                                             </div>
                                         </div>
                                     ))
                                 )}
                             </div>
 
                             {/* 페이징 */}
                             {reviewCount > itemsPerPage ? (
                                 <div className='prddetail_review_pagination'>
                                     <button onClick={handlePrev}><img src="/images/instrument/left.png" alt="왼쪽 버튼" /></button>
                                     {Array.from({ length: totalPages }, (_, i) => (
                                         <button key={i + 1} onClick={() => handlePageClick(i + 1)} className={currentPage === i + 1 ? 'active-page' : ''}>
                                             {i + 1}
                                         </button>
                                     ))}
                                     <button onClick={handleNext}><img src="/images/instrument/right.png" alt="오른쪽 버튼" /></button>
                                 </div>
                             ) : (
                                 <div className='prddetail_review_pagination'>
                                     <button disabled><img src="/images/instrument/left.png" alt="왼쪽 버튼" /></button>
                                     <button disabled><img src="/images/instrument/right.png" alt="오른쪽 버튼" /></button>
                                 </div>
                             )}
                         </>
                     ) : (
                         // 유효한 리뷰 없을 때
                         <div className='no_review_msg'>작성된 리뷰가 없습니다.</div>
                     )}
                 </div> 
            )}
        </div>
    );
}